<form id="form1" name="form1" method="post" action="admin_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Username </td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><label>
        <input name="usertxt" type="text" id="usertxt" />
      </label>
        </span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Password </td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label></label>
        <label></label>
        <label>
          <input name="pswtxt" type="password" id="pswtxt" maxlength="10" />
        </label>
        <span class="Font_Info_Psw">*Maksimal 10 karakter</span></span></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
