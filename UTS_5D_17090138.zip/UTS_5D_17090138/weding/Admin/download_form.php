<form id="form1" name="form1" method="post" action="download_tambah.php">
  <table width="400" border="0" align="left">
    <tr>
      <td width="10%" align="left" valign="top">Judul</td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="89%" align="left" valign="top"><label>
        <input name="judultxt" type="text" id="judultxt" size="35" />
      </label>
        </span></td>
    </tr>
    <tr>
      <td align="left" valign="top">Deskripsi</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label></label>
        <label></label>
        <label>
          <textarea name="deskripsitxt" cols="35" rows="4" id="deskripsitxt"></textarea>
        </label></td>
    </tr>
    <tr>
      <td align="left" valign="top">Url</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><label for="urltxt"></label>
      <input type="text" name="urltxt" id="urltxt" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">* Untuk [Url] Anda masukkan lokasi file yang bisa di didownload</td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><hr /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
      </label>
        <label>
          <input type="reset" name="Submit2" value="Batal" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
