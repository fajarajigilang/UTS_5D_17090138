<?php session_start();
if (ISSET($_SESSION['adminlogin']))
{
require("config.php");
$username = $_POST['usertxt'];
$pswlama = $_POST['pswlamatxt'];
$psw_tag = $_POST['pswbarutxt'];
$password = nl2br($psw_tag);
$password= str_replace("'","&acute;",$password);
	
$cari="select * from admintbl WHERE username ='".$username."'";
$hasil=mysqli_query($GLOBALS["___mysqli_ston"], $cari);
$data=mysqli_fetch_array($hasil);
if($data > 0){
$pswcek = $data['password'];
}
if ($pswcek <> md5($pswlama)) {
	echo "<li>Password lama salah, input dengan benar password lama Anda!</li>";
}else{
$perintah = "UPDATE admintbl set password = '".md5($password)."' where username = '".$username."'";
$result = mysqli_query($GLOBALS["___mysqli_ston"], $perintah);
	if ($result) {
		header("location:admin.php");
	} else { echo "Data belum dapat di ubah!!"; 
	}
}
}
?>