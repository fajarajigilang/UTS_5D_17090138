  <table width="400" border="0" align="left">
    <tr>
      <td width="50" height="37" align="center" valign="top"><a href="laporan_produk.php"><img src="../Gambar/Pdf.jpg" width="50" height="59" /></a></td>
      <td width="52" align="center" valign="top"><a href="laporan_member.php"><img src="../Gambar/Pdf.jpg" alt="" width="50" height="59" /></a></td>
      <td width="62" align="center" valign="top"><a href="laporan_pembelian.php"><img src="../Gambar/Pdf.jpg" alt="" width="50" height="59" /></a></td>
      <td width="55" align="center" valign="top"><a href="laporan_penjualan.php"><img src="../Gambar/Pdf.jpg" alt="" width="50" height="59" /></a></td>
    </tr>
    <tr>
      <td height="21" align="center" valign="top">Produk</td>
      <td align="center" valign="top">Member</td>
      <td align="center" valign="top">Pembelian</td>
      <td align="center" valign="top">Penjualan</td>
  </tr>
    <tr>
      <td height="21" colspan="4" align="center" valign="top"><hr /></td>
    </tr>
  </table>
