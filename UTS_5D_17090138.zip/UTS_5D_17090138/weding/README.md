*******************
What is Wedding Organizer
*******************

Wedding System is open source to meet the needs of the Wedding system.

*******************
Release Information Ibas Abilowo
*******************
Running in Xampp 5.5

Creat : Muhammad Nibras Abilowo (Ibas)
email : muhammadnibras1@gmail.com
hp    : 089 71 678 144

www.riniamirawedingorganizer.com (expired 1 month ago)
